﻿// ==================== TeacherSuit v6.0 ====================
// Librerie, strutture dati aggiornate, costanti, prototipi, main e menu

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <time.h>

#define MAX_VOTI 20
#define MAX_STUDENTI 30
#define MAX_CLASSI 10

// ====================== STRUTTURE DATI =============================
typedef struct {
    char nome[30];
    char cognome[30];
    char data_nascita[11]; // formato: gg/mm/aaaa
    int voti[MAX_VOTI];
    int num_voti;
    float media;
    char stato[15]; // SUFFICIENTE / INSUFFICIENTE / ?????
} Studente;

typedef struct {
    char nome[10];
    Studente studenti[MAX_STUDENTI];
    int num_studenti;
} Classe;

Classe registro[MAX_CLASSI];
int num_classi = 0;

// ====================== PROTOTIPI FUNZIONI =========================
void menuPrincipale();
void calcolatriceScientifica();
void registroStudenti();
void risolviEquazione2Grado();
void ordinamentoRicerca();
void convertitoreBasi();

float radiceIndice(float a, int n);
int fattoriale(int n);
float logBase(float base, float x);
float calcolaEspressione(char input[]);

void aggiungiClasse();
void aggiungiStudente();
void inserisciVoto();
void visualizzaRegistro();
void calcolaMediaEStato(Studente* s);
int fromBaseToDecimal(char* str, int base);
void fromDecimalToBase(int decimal, int base, char* output);

// ========================= FUNZIONE MAIN ===========================
int main() {
    menuPrincipale();
    return 0;
}

// ====================== MENU PRINCIPALE ============================
void menuPrincipale() {
    int scelta;
    do {
        printf("\n========= TeacherSuit v6.0 =========\n");
        printf("1. Calcolatrice scientifica interpretativa\n");
        printf("2. Registro studenti e medie\n");
        printf("3. Risolutore di equazioni di secondo grado\n");
        printf("4. Ordinamento e ricerca\n");
        printf("5. Convertitore basi numeriche\n");
        printf("0. Esci\n");
        printf("====================================\nScelta: ");
        scanf("%d", &scelta);
        getchar();

        switch (scelta) {
        case 1: calcolatriceScientifica(); break;
        case 2: registroStudenti(); break;
        case 3: risolviEquazione2Grado(); break;
        case 4: ordinamentoRicerca(); break;
        case 5: convertitoreBasi(); break;
        case 0: printf("Chiusura del programma...\n"); break;
        default: printf("Scelta non valida.\n"); break;
        }
    } while (scelta != 0);
}

// ==================== PARTE 2: CALCOLATRICE ========================
void calcolatriceScientifica() {
    char input[100];
    printf("\nInserisci un'espressione (es: 3+4, log2(8), sqrt(9), √3(27), fatt(5), sin(1.57)):\n> ");
    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = '\0';

    float risultato = calcolaEspressione(input);
    printf("Risultato: %.6f\n", risultato);
}

float calcolaEspressione(char input[]) {
    float x, y;
    int n;
    if (strstr(input, "+")) {
        sscanf(input, "%f+%f", &x, &y);
        return x + y;
    }
    else if (strstr(input, "-")) {
        sscanf(input, "%f-%f", &x, &y);
        return x - y;
    }
    else if (strstr(input, "*")) {
        sscanf(input, "%f*%f", &x, &y);
        return x * y;
    }
    else if (strstr(input, "/")) {
        sscanf(input, "%f/%f", &x, &y);
        return (y != 0) ? x / y : 0;
    }
    else if (strstr(input, "^") != NULL) {
        sscanf(input, "%f^%d", &x, &n);
        return pow(x, n);
    }
    else if (strncmp(input, "sqrt(", 5) == 0) {
        sscanf(input, "sqrt(%f)", &x);
        return sqrt(x);
    }
    else if (strncmp(input, "ln(", 3) == 0) {
        sscanf(input, "ln(%f)", &x);
        return log(x);
    }
    else if (strncmp(input, "log(", 4) == 0) {
        sscanf(input, "log(%f)", &x);
        return log10(x);
    }
    else if (strncmp(input, "log", 3) == 0) {
        sscanf(input, "log%d(%f)", &n, &x);
        return logBase((float)n, x);
    }
    else if (strncmp(input, "√", 2) == 0) {
        sscanf(input, "√%d(%f)", &n, &x);
        return radiceIndice(x, n);
    }
    else if (strncmp(input, "fatt(", 5) == 0) {
        sscanf(input, "fatt(%d)", &n);
        return (float)fattoriale(n);
    }
    else if (strncmp(input, "sin(", 4) == 0) {
        sscanf(input, "sin(%f)", &x);
        return sin(x);
    }
    else if (strncmp(input, "cos(", 4) == 0) {
        sscanf(input, "cos(%f)", &x);
        return cos(x);
    }
    else if (strncmp(input, "tan(", 4) == 0) {
        sscanf(input, "tan(%f)", &x);
        return tan(x);
    }
    else {
        printf("Espressione non riconosciuta.\n");
        return 0;
    }
}

float radiceIndice(float a, int n) {
    return pow(a, 1.0 / n);
}

int fattoriale(int n) {
    if (n < 0) return -1;
    int result = 1;
    for (int i = 2; i <= n; i++) result *= i;
    return result;
}

float logBase(float base, float x) {
    return log(x) / log(base);
}

// ==================== PARTE 3: REGISTRO STUDENTI ===================
void registroStudenti() {
    int scelta;
    do {
        printf("\n=== Registro Studenti ===\n");
        printf("1. Aggiungi classe\n");
        printf("2. Aggiungi studente a una classe\n");
        printf("3. Inserisci voto a uno studente\n");
        printf("4. Visualizza registro completo\n");
        printf("0. Torna al menu principale\nScelta: ");
        scanf("%d", &scelta);
        getchar();

        switch (scelta) {
        case 1: aggiungiClasse(); break;
        case 2: aggiungiStudente(); break;
        case 3: inserisciVoto(); break;
        case 4: visualizzaRegistro(); break;
        case 0: break;
        default: printf("Scelta non valida.\n"); break;
        }
    } while (scelta != 0);
}

void aggiungiClasse() {
    if (num_classi >= MAX_CLASSI) {
        printf("Numero massimo di classi raggiunto.\n");
        return;
    }
    printf("Nome della nuova classe: ");
    fgets(registro[num_classi].nome, sizeof(registro[num_classi].nome), stdin);
    registro[num_classi].nome[strcspn(registro[num_classi].nome, "\n")] = '\0';
    registro[num_classi].num_studenti = 0;
    num_classi++;
    printf("Classe aggiunta con successo!\n");
}

void aggiungiStudente() {
    int index;
    printf("Inserisci indice classe (0-%d): ", num_classi - 1);
    scanf("%d", &index);
    getchar();
    if (index < 0 || index >= num_classi || registro[index].num_studenti >= MAX_STUDENTI) {
        printf("Errore: indice non valido o classe piena.\n");
        return;
    }
    Studente* s = &registro[index].studenti[registro[index].num_studenti];
    printf("Nome: "); fgets(s->nome, sizeof(s->nome), stdin); s->nome[strcspn(s->nome, "\n")] = '\0';
    printf("Cognome: "); fgets(s->cognome, sizeof(s->cognome), stdin); s->cognome[strcspn(s->cognome, "\n")] = '\0';
    printf("Data di nascita (gg/mm/aaaa): "); fgets(s->data_nascita, sizeof(s->data_nascita), stdin); s->data_nascita[strcspn(s->data_nascita, "\n")] = '\0';
    s->num_voti = 0;
    s->media = 0;
    strcpy(s->stato, "?????");
    registro[index].num_studenti++;
    printf("Studente aggiunto con successo!\n");
}

void inserisciVoto() {
    int ci, si, voto;
    printf("Indice classe: "); scanf("%d", &ci);
    printf("Indice studente: "); scanf("%d", &si);
    printf("Voto (0-10): "); scanf("%d", &voto);
    getchar();

    if (ci >= 0 && ci < num_classi && si >= 0 && si < registro[ci].num_studenti && registro[ci].studenti[si].num_voti < MAX_VOTI) {
        Studente* s = &registro[ci].studenti[si];
        s->voti[s->num_voti++] = voto;
        calcolaMediaEStato(s);
        printf("Voto inserito.\n");
    }
    else {
        printf("Errore nei dati inseriti.\n");
    }
}

void calcolaMediaEStato(Studente* s) {
    int somma = 0;
    if (s->num_voti == 0) {
        strcpy(s->stato, "?????");
        return;
    }
    for (int i = 0; i < s->num_voti; i++) {
        somma += s->voti[i];
    }
    s->media = (float)somma / s->num_voti;
    if (s->media >= 6.0) {
        strcpy(s->stato, "SUFFICIENTE");
    }
    else {
        strcpy(s->stato, "INSUFFICIENTE");
    }
}

void visualizzaRegistro() {
    for (int i = 0; i < num_classi; i++) {
        printf("\nClasse: %s\n", registro[i].nome);
        for (int j = 0; j < registro[i].num_studenti; j++) {
            Studente* s = &registro[i].studenti[j];
            printf("%d. %s %s, Nato il: %s\n", j, s->nome, s->cognome, s->data_nascita);
            printf("   Voti: ");
            for (int k = 0; k < s->num_voti; k++) printf("%d ", s->voti[k]);
            printf("\n   Media: %.2f | Stato: %s\n", s->media, s->stato);
        }
    }
}

// ==================== PARTE 4: EQUAZIONI SECONDO GRADO =============
void risolviEquazione2Grado() {
    float a, b, c;
    printf("\nEquazione nella forma ax^2 + bx + c = 0\n");
    printf("Inserisci a: "); scanf("%f", &a);
    printf("Inserisci b: "); scanf("%f", &b);
    printf("Inserisci c: "); scanf("%f", &c);

    if (a == 0) {
        printf("Non è un'equazione di secondo grado.\n");
        return;
    }

    float delta = b * b - 4 * a * c;
    printf("Delta = %.2f\n", delta);

    if (delta < 0) {
        printf("Nessuna soluzione reale.\n");
    }
    else if (delta == 0) {
        float x = -b / (2 * a);
        printf("Una sola soluzione reale: x = %.2f\n", x);
    }
    else {
        float x1 = (-b + sqrt(delta)) / (2 * a);
        float x2 = (-b - sqrt(delta)) / (2 * a);
        printf("Due soluzioni reali: x1 = %.2f, x2 = %.2f\n", x1, x2);
    }
}

// ==================== PARTE 5: ORDINAMENTO E RICERCA ===============
void selectionSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int min_idx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[min_idx]) min_idx = j;
        }
        int temp = arr[i];
        arr[i] = arr[min_idx];
        arr[min_idx] = temp;
    }
}

void bubbleSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void merge(int arr[], int l, int m, int r) {
    int n1 = m - l + 1, n2 = r - m;
    int* L = malloc(n1 * sizeof(int));
    int* R = malloc(n2 * sizeof(int));
    for (int i = 0; i < n1; i++) L[i] = arr[l + i];
    for (int j = 0; j < n2; j++) R[j] = arr[m + 1 + j];
    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2) arr[k++] = (L[i] <= R[j]) ? L[i++] : R[j++];
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
    free(L); free(R);
}

void mergeSort(int arr[], int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}

int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = (low - 1);
    for (int j = low; j <= high - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    int temp = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = temp;
    return (i + 1);
}

void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int ricercaSequenziale(int arr[], int n, int target) {
    for (int i = 0; i < n; i++) {
        if (arr[i] == target) return i;
    }
    return -1;
}

int ricercaBinaria(int arr[], int left, int right, int target) {
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == target) return mid;
        if (arr[mid] < target) left = mid + 1;
        else right = mid - 1;
    }
    return -1;
}

void ordinamentoRicerca() {
    int n, scelta, ricerca, target;
    printf("\nQuanti elementi vuoi (max 10000)? ");
    scanf("%d", &n);
    int* arr = malloc(n * sizeof(int));
    srand(time(NULL));

    printf("1. Inserisci manualmente\n2. Genera random\nScelta: ");
    scanf("%d", &scelta);
    if (scelta == 1) {
        for (int i = 0; i < n; i++) {
            printf("Elemento %d: ", i);
            scanf("%d", &arr[i]);
        }
    }
    else {
        for (int i = 0; i < n; i++) arr[i] = rand() % 100;
    }

    printf("\nScegli algoritmo di ordinamento:\n1. SelectionSort\n2. BubbleSort\n3. QuickSort\n4. MergeSort\n5. TimSort (simulato con QuickSort)\nScelta: ");
    scanf("%d", &scelta);

    clock_t start = clock();
    switch (scelta) {
    case 1: selectionSort(arr, n); break;
    case 2: bubbleSort(arr, n); break;
    case 3: quickSort(arr, 0, n - 1); break;
    case 4: mergeSort(arr, 0, n - 1); break;
    case 5: quickSort(arr, 0, n - 1); break;
    default: printf("Scelta non valida\n"); free(arr); return;
    }
    clock_t end = clock();
    double tempo = (double)(end - start) / CLOCKS_PER_SEC;
    printf("\nOrdinamento completato in %.6f secondi.\n", tempo);

    printf("\nVuoi cercare un elemento? 1=Sì, 0=No: ");
    scanf("%d", &ricerca);
    if (ricerca) {
        printf("Elemento da cercare: ");
        scanf("%d", &target);
        printf("Metodo: 1=Sequenziale, 2=Binario: ");
        scanf("%d", &scelta);

        start = clock();
        int pos = -1;
        if (scelta == 1) pos = ricercaSequenziale(arr, n, target);
        else if (scelta == 2) pos = ricercaBinaria(arr, 0, n - 1, target);
        else printf("Scelta non valida\n");
        end = clock();

        tempo = (double)(end - start) / CLOCKS_PER_SEC;
        if (pos >= 0)
            printf("Trovato in posizione %d in %.6f secondi\n", pos, tempo);
        else
            printf("Non trovato. Tempo impiegato: %.6f secondi\n", tempo);
    }

    printf("\nArray ordinato:\n");
    for (int i = 0; i < n; i++) printf("%d ", arr[i]);
    printf("\n");
    free(arr);
}

// ==================== PARTE 6: CONVERTITORE BASI NUMERICHE =========
int fromBaseToDecimal(char* str, int base) {
    return (int)strtol(str, NULL, base);
}

void fromDecimalToBase(int decimal, int base, char* output) {
    char temp[65];
    char digits[] = "0123456789ABCDEF";
    int i = 0;
    do {
        temp[i++] = digits[decimal % base];
        decimal /= base;
    } while (decimal > 0);
    temp[i] = '\0';
    // reverse
    for (int j = 0; j < i; j++) {
        output[j] = temp[i - j - 1];
    }
    output[i] = '\0';
}

void convertitoreBasi() {
    char input[65], output[65];
    int baseInput, baseOutput, numeroDecimale;

    printf("\nInserisci il numero da convertire: ");
    scanf("%s", input);
    printf("Base del numero inserito (2/8/10/16): ");
    scanf("%d", &baseInput);
    printf("Base di destinazione (2/8/10/16): ");
    scanf("%d", &baseOutput);

    if ((baseInput != 2 && baseInput != 8 && baseInput != 10 && baseInput != 16) ||
        (baseOutput != 2 && baseOutput != 8 && baseOutput != 10 && baseOutput != 16)) {
        printf("Base non supportata!\n");
        return;
    }

    numeroDecimale = fromBaseToDecimal(input, baseInput);

    if (baseOutput == 10) {
        printf("Risultato: %d\n", numeroDecimale);
    }
    else {
        fromDecimalToBase(numeroDecimale, baseOutput, output);
        printf("Risultato: %s\n", output);
    }
}